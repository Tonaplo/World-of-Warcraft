CandyBuckets
======================

Candy Buckets makes it easier to track several world event objectives:
- Hallow's End
- Lunar Festival
- Midsummer Fire Festival

Features implemented:
- Simple overview on zone and continent views.
- Works with the default map, probably not with other map related addons.
