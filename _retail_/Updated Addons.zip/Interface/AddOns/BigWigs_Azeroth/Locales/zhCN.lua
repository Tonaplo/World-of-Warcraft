local L = BigWigs:NewBossLocale("Warbringer Yenajz", "zhCN")
if not L then return end
if L then
	L.tear = "你站在时空裂痕上"
end
