# BigWigs

## [v150](https://github.com/BigWigsMods/BigWigs/tree/v150) (2019-06-26)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v149.3...v150)

- bump version  
- bump toc  
- CrucibleOfStorms/Uunat: Fix Stuck Oblivion Tears  
- Update option files  
- EternalPalace: Remove testbuild check in prep for 8.2  
- EternalPalace/LadyAshvane: local function fix  
- EternalPalace/LadyAshvane: Refinement  
- EternalPalace/BlackwaterBehemoth: Fix option keys  
- EternalPalace/BlackwaterBehemoth: Updates  
- EternalPalace/Orgozoa: Rename from The Hatchery and initial update  
- EternalPalace/LadyAshvane: Updating Arcing Azerite marking, use raidid to assign certain icons first  
- Update zhCN/zhTW (#681)  
- Update zhCN (#682)  
- EternalPalace/Zaqul: Updates  
- EternalPalace/QueenAzshara: Fix Decrees  
- EternalPalace/QueenAzshara: Updates  
- CrucibleOfStorms/Cabal: Update berserk timer on Mythic  
- EternalPalace/Zaqul: Add initial update for PTR  
