
BigWigs:AddColors("Abyssal Commander Sivara", {
	[-20300] = {"blue","green","purple"},
	[-20006] = {"blue","yellow"},
	[294726] = "blue",
	[295332] = "purple",
	[295601] = {"blue","orange"},
	[295791] = {"blue","orange","yellow"},
	[296551] = "red",
})

BigWigs:AddColors("Radiance of Azshara", {
	[295916] = "cyan",
	[296428] = "yellow",
	[296459] = "yellow",
	[296546] = {"blue","purple"},
	[296701] = "orange",
	[296737] = {"blue","yellow"},
	[296894] = "yellow",
})

BigWigs:AddColors("Blackwater Behemoth", {
	[292083] = "cyan",
	[292127] = "blue",
	[292133] = "green",
	[292138] = "green",
	[292159] = {"blue","yellow"},
	[292205] = "green",
	[292270] = "orange",
	[292307] = "blue",
	[298428] = {"blue","purple"},
	[301180] = "blue",
	[301494] = {"blue","red"},
	["stages"] = {"cyan","green"},
})

BigWigs:AddColors("Lady Ashvane", {
	[-20096] = {"blue","yellow"},
	[296569] = {"cyan","yellow"},
	[296725] = {"blue","purple"},
	[297397] = {"blue","red"},
	[298056] = "orange",
	["stages"] = "orange",
})

BigWigs:AddColors("Orgozoa", {
	[295779] = {"blue","yellow"},
	[295822] = "red",
	[296691] = "orange",
	[298103] = "orange",
	[298156] = {"blue","purple"},
	[298242] = "yellow",
	[298465] = "cyan",
	[298548] = "cyan",
	[305048] = "red",
	["stages"] = {"cyan","green"},
})

BigWigs:AddColors("The Queen's Court", {
	[296716] = "red",
	[296851] = {"blue","yellow"},
	[297325] = "red",
	[297566] = "cyan",
	[297585] = {"blue","cyan"},
	[297656] = {"blue","cyan"},
	[298050] = {"cyan","yellow"},
	[299914] = {"blue","yellow"},
	[300088] = "cyan",
	[300545] = "blue",
	[301244] = "cyan",
	[301807] = "red",
	[301830] = {"blue","purple"},
	[301947] = "yellow",
})

BigWigs:AddColors("Za'qul, Herald of Ny'alotha", {
	[292963] = {"blue","yellow"},
	[292971] = "blue",
	[292996] = "cyan",
	[293509] = {"blue","yellow"},
	[294535] = "yellow",
	[295099] = {"blue","green"},
	[295814] = "red",
	[296018] = {"blue","yellow"},
	[298192] = "blue",
	[299702] = "yellow",
	[301141] = "orange",
	[303971] = "red",
	[304733] = "orange",
	["stages"] = "cyan",
})

BigWigs:AddColors("Queen Azshara", {
	[-20480] = "cyan",
	[297371] = "cyan",
	[297372] = "cyan",
	[297907] = "blue",
	[297912] = "red",
	[297934] = "orange",
	[297937] = "orange",
	[297972] = "orange",
	[298014] = {"blue","purple"},
	[298021] = "purple",
	[298121] = "cyan",
	[298531] = "orange",
	[298569] = "blue",
	[298756] = {"blue","purple"},
	[298787] = "yellow",
	[299094] = {"blue","yellow"},
	[299250] = {"blue","cyan"},
	[300074] = "orange",
	[300428] = "cyan",
	[300492] = {"blue","yellow"},
	[300519] = "red",
	[300620] = {"blue","yellow"},
	[300743] = {"blue","purple"},
	[300807] = "red",
	[301078] = {"blue","yellow"},
	[302999] = "blue",
	[303657] = {"blue","yellow"},
	[303980] = "yellow",
	[304475] = "cyan",
	["stages"] = {"cyan","green"},
})
