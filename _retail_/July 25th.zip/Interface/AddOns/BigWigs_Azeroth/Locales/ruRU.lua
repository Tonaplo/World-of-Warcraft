local L = BigWigs:NewBossLocale("Warbringer Yenajz", "ruRU")
if not L then return end
if L then
	L.tear = "Вы стоите в Разрыве Реальности"
end
