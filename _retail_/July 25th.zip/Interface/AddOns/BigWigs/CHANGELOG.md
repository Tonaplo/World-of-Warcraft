# BigWigs

## [v160](https://github.com/BigWigsMods/BigWigs/tree/v160) (2019-07-24)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v159.1...v160)

- bump version  
- EternalPalace/LadyAshvane: Fix error  
